public interface Pet {
    void play();
}
