public class Cat {
    public void play() {
        System.out.println("The cat plays with its owner.");
    }
}
