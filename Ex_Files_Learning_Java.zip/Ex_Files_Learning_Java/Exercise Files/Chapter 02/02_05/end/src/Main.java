import java.awt.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

    //    System.out.println("Enter a word:");

        Scanner sc = new Scanner(System.in);
        int userNumber = sc.nextInt();
        System.out.println(userNumber);
        double userNumber2 = sc.nextDouble();
        System.out.println(userNumber2);
/*
        String userInput = sc.next();

        String uppercased = userInput.toUpperCase();
        System.out.println(userInput);
        System.out.println(uppercased);

        char firstCharacter = userInput.charAt(0);
        System.out.println(firstCharacter);

        System.out.println("Contains: " +
                userInput.contains("Enter".toLowerCase()));

*/

    }
}
