public class Dog implements Pet {
    public void play() {
        System.out.println("The dog plays with its owner.");
    }
}
