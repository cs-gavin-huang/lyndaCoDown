public class Dog {
    public void play() {
        System.out.println("The dog plays with its owner.");
    }
}
