import java.awt.*;

public class Main {

    public static void main(String[] args) {
        String s = "dog";
        String replacedF = s.replace('d', 'f');
        System.out.println(replacedF);
    }
}
